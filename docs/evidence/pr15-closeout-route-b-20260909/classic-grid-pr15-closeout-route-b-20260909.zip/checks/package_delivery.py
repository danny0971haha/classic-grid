"""Package only this reconciliation's selected evidence; do not alter original packets."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, re, shutil, stat, tarfile, zipfile
root = Path('/private/tmp/classic-closeout-20260909')
publish = Path('/private/tmp/classic-closeout-publication-20260909/docs/evidence/pr15-closeout-route-b-20260909')
publish.mkdir(parents=True, exist_ok=True)
patterns = {
 'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
 'github_token': rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})',
 'aws_access': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'telegram_token': rb'\b[0-9]{8,12}:[A-Za-z0-9_-]{35}\b',
 'credential_url': rb'https?://[^\s/\"\x27:@]+:[^\s/\"\x27@]+@',
 'long_bearer': rb'Bearer [A-Za-z0-9._-]{30,}',
}
hits=[]; scanned=0; archives=0

def safe(name):
 p=PurePosixPath(name)
 assert not p.is_absolute() and '..' not in p.parts and '\\' not in name

def scan(name, data, depth=0):
 global scanned, archives
 scanned+=1
 for label, pattern in patterns.items():
  if re.search(pattern,data): hits.append({'path':name,'pattern':label})
 assert depth <= 5
 if data[:4]==b'PK\x03\x04':
  archives+=1
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   names=z.namelist(); assert len(set(names))==len(names)
   for member in z.infolist():
    safe(member.filename); assert not stat.S_ISLNK(member.external_attr>>16)
    if not member.is_dir():scan(name+'!/'+member.filename,z.read(member),depth+1)
 elif data[:2]==b'\x1f\x8b':
  archives+=1
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
   names=[m.name for m in t.getmembers()]; assert len(set(names))==len(names)
   for member in t.getmembers():
    safe(member.name); assert member.isfile() or member.isdir()
    if member.isfile():scan(name+'!/'+member.name,t.extractfile(member).read(),depth+1)

files=sorted(f for f in root.rglob('*') if f.is_file() and f.name not in {'FILE_MANIFEST.json','delivery-secret-scan.json'})
for file in files:
 assert not file.is_symlink();safe(str(file.relative_to(root)));scan(str(file.relative_to(root)),file.read_bytes())
assert not hits, hits
scan_result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Selected repository evidence, raw downloads, expanded copies and nested archives; no HOME, environment or credential-store collection','itemsScannedIncludingNested':scanned,'archivesInspected':archives,'credentialPatterns':list(patterns),'hits':hits,'originalEvidenceRedactedOrReserializedThisReview':False,'universalSecretAbsenceClaim':False}
(root/'checks/delivery-secret-scan.json').write_text(json.dumps(scan_result,indent=2)+'\n')
files=sorted(f for f in root.rglob('*') if f.is_file() and f.name!='FILE_MANIFEST.json')
manifest=[{'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'mode':oct(stat.S_IMODE(f.stat().st_mode)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
(root/'FILE_MANIFEST.json').write_text(json.dumps({'scope':'Exact delivery file bytes; manifest excludes itself; authenticating outer ZIP uses publication SHA256SUMS','files':manifest},indent=2)+'\n')
archive=publish/'classic-grid-pr15-closeout-route-b-20260909.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in files+[root/'FILE_MANIFEST.json']: z.write(file,str(file.relative_to(root)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={r['path'] for r in manifest}|{'FILE_MANIFEST.json'}
 for row in manifest:
  assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
for name in ['REPORT.md','ab-review.md','scoped-review.md']:
 shutil.copy2(root/name,publish/name)
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(publish/'README.md').write_text('''# Classic Grid PR15 closeout and fixed-target Route B materials

Read [REPORT.md](REPORT.md) first; [A/B details](ab-review.md) and [scoped details](scoped-review.md) separate engineering delivery and historical product evidence.

[Download the ChatGPT-readable ZIP](classic-grid-pr15-closeout-route-b-20260909.zip). It includes original CI downloads/logs, byte reconciliation, source references and detailed reports. Verify [SHA256SUMS](SHA256SUMS), then the ZIP's FILE_MANIFEST.json; original nested artifacts retain their own checksums.

`NO_NEW_CODE_CHANGE_REQUIRED`. PR15 stays at `ff3d896c427c3d0ca2833879655157029040e044`. This evidence-only publication does not change a tested candidate, trigger new CI, adopt Route B, clear root dependencies, or grant independent acceptance/merge/deployment/trading authorization.

ZIP SHA-256: `'''+sha+'`\n')
(publish/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in sorted(publish.iterdir()) if f.name!='SHA256SUMS'))
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'files':len(manifest)+1,'scan':scan_result},indent=2))

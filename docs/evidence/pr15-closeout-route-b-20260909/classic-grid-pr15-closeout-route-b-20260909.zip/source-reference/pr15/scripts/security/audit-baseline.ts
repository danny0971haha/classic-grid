import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import {
  BASELINE_RELATIVE_PATH,
  LOCKFILE_RELATIVE_PATH,
  actionInventoryDocument,
  evaluateAuditPolicy,
  failedPolicy,
  inventoryGitRepository,
  parseAuditReport,
  readAuditFile,
  repoPath,
  sanitizeForArtifact,
  sha256File,
  verificationDocument,
  type AuditBaseline,
  type PolicyResult,
} from "./audit-policy.js";

export const SECURITY_ARTIFACT_DIR = "artifacts/security";

export function repoRootFromHere(): string {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
}

// Audit output paths alone support absolute destinations; repoPath retains its contract.
function writeOutput(root: string, outputPath: string, contents: string): void {
  const full = path.resolve(root, outputPath);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, sanitizeForArtifact(contents, root));
}

export type AuditCommandOptions = {
  executable?: string;
  args?: string[];
  cwd?: string;
  env?: NodeJS.ProcessEnv;
};

export function runNpmAudit(root: string, diagnosticDir?: string, options: AuditCommandOptions = {}): { ok: true; raw: string } | { ok: false; code: "AUDIT_COMMAND_FAILED"; stderr: string } {
  const executable = options.executable ?? "npm";
  const args = options.args ?? ["audit", "--omit=dev", "--json"];
  const spawned = spawnSync(executable, args, {
    cwd: options.cwd ?? root,
    encoding: "utf8",
    maxBuffer: 32 * 1024 * 1024,
    env: options.env ?? process.env,
  });
  if (diagnosticDir) {
    // Capture the same invocation, including registry/error JSON. Never rerun an
    // audit to explain a prior failure or substitute this document for policy.
    const full = path.resolve(root, diagnosticDir, "audit-command.json");
    fs.mkdirSync(path.dirname(full), { recursive: true });
    const redact = (value: string) => sanitizeForArtifact(value, root)
      .replace(/(https?:\/\/)[^\s/"@]+@/gi, "$1[redacted]@")
      .replace(/((?:_authToken|_auth|token|password)\s*[=:]\s*)[^\s,"}]+/gi, "$1[redacted]");
    fs.writeFileSync(full, `${JSON.stringify({
      schemaVersion: "classic-audit-command-diagnostic/1",
      command: [executable, ...args].map(redact),
      capturedAt: new Date().toISOString(),
      status: spawned.status,
      signal: spawned.signal,
      error: spawned.error ? redact(String(spawned.error)) : null,
      stdout: redact(spawned.stdout || ""),
      stderr: redact(spawned.stderr || ""),
      streamsAreSanitized: true,
      authorizationGranted: false,
    }, null, 2)}\n`);
  }
  if (spawned.error || spawned.status === null) {
    return { ok: false, code: "AUDIT_COMMAND_FAILED", stderr: spawned.stderr || String(spawned.error || "spawn failed") };
  }
  if (spawned.status !== 0 && spawned.status !== 1) {
    return { ok: false, code: "AUDIT_COMMAND_FAILED", stderr: spawned.stderr || `exit ${spawned.status}` };
  }
  if (typeof spawned.stdout !== "string" || spawned.stdout.trim().length === 0) {
    return { ok: false, code: "AUDIT_COMMAND_FAILED", stderr: spawned.stderr || "empty stdout" };
  }
  return { ok: true, raw: spawned.stdout };
}

function commandFailedResult(baseline: AuditBaseline, lockfileSha256: string, code: "AUDIT_FILE_MISSING" | "AUDIT_COMMAND_FAILED"): PolicyResult {
  return failedPolicy(code, lockfileSha256, baseline.lockfile.sha256);
}

function writeActionInventory(root: string, outDir: string): ReturnType<typeof inventoryGitRepository> {
  const actionInventory = inventoryGitRepository(root, { requireProductionPins: true });
  writeOutput(
    root,
    path.join(outDir, "action-pin-inventory.json"),
    `${JSON.stringify(actionInventoryDocument(actionInventory), null, 2)}\n`,
  );
  return actionInventory;
}

export function runAuditBaseline(root = repoRootFromHere(), options: {
  auditJsonPath?: string;
  outDir?: string;
} = {}): PolicyResult {
  const outDir = options.outDir ?? SECURITY_ARTIFACT_DIR;
  const baseline = JSON.parse(fs.readFileSync(repoPath(root, BASELINE_RELATIVE_PATH), "utf8")) as AuditBaseline;
  const lockfileSha256 = sha256File(repoPath(root, LOCKFILE_RELATIVE_PATH));

  let auditRaw: string;
  if (options.auditJsonPath) {
    const loaded = readAuditFile(options.auditJsonPath);
    if (!loaded.ok) {
      const result = commandFailedResult(baseline, lockfileSha256, "AUDIT_FILE_MISSING");
      writeOutput(root, path.join(outDir, "audit-baseline-verification.json"), `${JSON.stringify(verificationDocument(result), null, 2)}\n`);
      writeActionInventory(root, outDir);
      return result;
    }
    auditRaw = loaded.raw;
  } else {
    const audited = runNpmAudit(root, outDir);
    if (!audited.ok) {
      const result = commandFailedResult(baseline, lockfileSha256, "AUDIT_COMMAND_FAILED");
      writeOutput(root, path.join(outDir, "audit-baseline-verification.json"), `${JSON.stringify(verificationDocument(result), null, 2)}\n`);
      writeActionInventory(root, outDir);
      return result;
    }
    auditRaw = audited.raw;
  }

  const parsed = parseAuditReport(auditRaw);
  const result = parsed.ok
    ? evaluateAuditPolicy({ baseline, lockfileSha256, parsed })
    : evaluateAuditPolicy({ baseline, lockfileSha256, auditRaw });

  writeOutput(root, path.join(outDir, "audit.json"), `${JSON.stringify(parsed.ok ? parsed.raw : { malformed: true }, null, 2)}\n`);
  writeOutput(root, path.join(outDir, "audit-baseline-verification.json"), `${JSON.stringify(verificationDocument(result), null, 2)}\n`);
  writeOutput(root, path.join(outDir, "package-lock.sha256"), `${lockfileSha256}  ${LOCKFILE_RELATIVE_PATH}\n`);
  writeActionInventory(root, outDir);
  return result;
}

function isMain(argv1: string | undefined): boolean {
  return typeof argv1 === "string" && pathToFileURL(path.resolve(argv1)).href === import.meta.url;
}

function main(argv: string[]): void {
  const root = repoRootFromHere();
  if (argv[0] === "sanitize-log" && argv.length === 1) {
    const input = fs.readFileSync(0, "utf8");
    process.stdout.write(sanitizeForArtifact(input, root));
    return;
  }
  const values = new Map<string, string>();
  for (let index = 0; index < argv.length; index += 2) {
    const option = argv[index];
    if (option !== "--audit-json" && option !== "--out-dir") {
      throw new Error("AUDIT_ARGUMENT_UNSUPPORTED");
    }
    if (values.has(option)) throw new Error("AUDIT_ARGUMENT_DUPLICATE");
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error("AUDIT_ARGUMENT_VALUE_MISSING");
    values.set(option, value);
  }
  const auditJsonPath = values.get("--audit-json");
  const outDir = values.get("--out-dir");
  const result = runAuditBaseline(root, { auditJsonPath, outDir });
  const actions = inventoryGitRepository(root, { requireProductionPins: true });
  if (!result.ok || !actions.overallPolicyOk) {
    console.error(JSON.stringify({
      ok: false,
      codes: result.codes,
      actionCodes: actions.codes,
      metadataMatchesObserved: result.metadataMatchesObserved,
      overallPolicyOk: false,
    }, null, 2));
    process.exit(1);
  }
  console.log(JSON.stringify({
    ok: true,
    codes: result.codes,
    metadata: result.metadata,
    observed: result.observed,
    metadataMatchesObserved: result.metadataMatchesObserved,
    high: result.highCount,
    critical: result.criticalCount,
    total: result.totalCount,
    resolvedHigh: result.resolvedHigh.map((row) => row.advisoryId),
    actionUsesTotal: actions.actionUsesTotal,
    unpinnedExternalActions: actions.unpinnedExternalActions,
    unsafeCheckouts: actions.unsafeCheckouts,
    existingHighAreNotCleared: true,
  }, null, 2));
}

if (isMain(process.argv[1])) {
  main(process.argv.slice(2));
}

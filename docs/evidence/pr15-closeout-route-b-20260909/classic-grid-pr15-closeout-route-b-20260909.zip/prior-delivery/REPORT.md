# Classic Grid CI inventory / evidence correction — 2026-09-09

本輪只處理 danny0971haha/classic-grid。修正清冊預期與歷史證據交付格式；保留 root dependency audit 政策。本報告不授予獨立接受、merge、deploy 或交易權限。

## 實際身分與交付

- Draft PR: https://github.com/danny0971haha/classic-grid/pull/15
- Branch: `fix/classic-ci-inventory-evidence-20260909`
- Base branch: `fix/classic-canary-driver-20260909`
- Base HEAD: `40223bb5e106668e2d5a2c8971579b41e7a9dbfa`
- Base tree: `c99180aab2b4cf9b4abb40780c7d2192686d9eec`
- New commit: `ff3d896c427c3d0ca2833879655157029040e044`
- New tree: `fb693000a7ea157b0995ee9b58592c53ce072419`
- Commit subject: `fix(ci): reconcile workflow inventory and preserve historical evidence archive`
- Task worktree: `/private/tmp/classic-ci-inventory-evidence-20260909`
- Normal push exit 0; local HEAD = remote branch SHA = Draft PR head (`published-identity.json`).
- PR #14 保持原 branch/base/HEAD，作為 attempt 2 比較基準。没有 reset/rebase/force-push、merge、deploy、repository settings 改動、交易憑證使用或交易所連線／交易。

## A：清冊校正，不是安全判定放寬

僅修改 `test/security/action-pin.test.ts`、`test/security/action-trust-git.test.ts`。完整 Git tracked inventory 掃描器原本就正確掃描兩個 workflows；錯誤是兩個正向測試只預期 `ci.yml`。

現在逐項比較 `trackedManifests`、`scannedFiles` 的精確兩個檔案，以及七個完整 occurrence tuples：

| Manifest | Action identity | Full SHA | Occurrences |
| --- | --- | --- | ---: |
| `.github/workflows/ci.yml` | actions/checkout | `11d5960a326750d5838078e36cf38b85af677262` | 1 |
| `.github/workflows/ci.yml` | actions/setup-node | `49933ea5288caeca8642d1e84afbd3f7d6820020` | 1 |
| `.github/workflows/ci.yml` | actions/upload-artifact | `ea165f8d65b6e75b540449e92b4886f43607fa02` | 4 |
| `.github/workflows/classic-canary-scoped.yml` | actions/upload-artifact | `ea165f8d65b6e75b540449e92b4886f43607fa02` | 1 |

兩個反例在真實 temporary Git repo 複製當前兩份 workflows，先確認原內容符合 production pin policy，再將 scoped upload 分別改為 `v4` 或 `bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb`。原掃描器分別拒絕未 immutable / 不在 allowlist 的值，`overallPolicyOk=false`。全部原有 Docker、symlink、YAML、local/reusable workflows、immutable pin、allowlist 與負向測試均保留。

## B：原始 bytes 無損保存

Attempt 2 原始 whitespace 日誌的完整範圍：

| Original path under `docs/evidence/classic-canary-review-20260908/` | Error |
| --- | --- |
| `classic-canary-review-handoff.md` | trailing whitespace lines 18, 54, 55 |
| `offline/unavailable-venue.txt` | EOF blank line 17 |
| `registry/canary-audit.json` | EOF blank line 23 |

先完成 47 個原 tracked files 的用途／blob／SHA256／模式與引用盤點；全部 313,383 bytes、模式 100644。沒有找到要求這組歷史檔案必須展開留在當前 tree 的明確契約。完整 packet（含舊 `SHA256SUMS`）保存到 `original-evidence.tar.gz`；新 README、archive manifest、verify/restore CLI 與 package checksum 均限定在同一證據目錄。原始日誌、audit JSON、時間、退出碼、結果、身分、雜湊未 trim 或重序列化。

移除展開副本前已還原，比較來源 Git blob／當前副本／還原 bytes、模式及原 45-entry manifest。移除後主代理再次獨立 restore，逐檔吻合原 Git，並與未更動的 Linux packet 47-entry 雜湊清單一致。新 manifest 涵蓋原 manifest 未列出的自身與 `identity-after-packet.txt`；新 checksum 不雜湊自己。

Archive SHA256: `aa60ca2154db0d0b49f14c2093932049be70255624b65d72f77262cb2cae7c38`。

七個 archive 反例（traversal、absolute path、duplicate、corruption、symlink、錯誤 mode、缺檔）均拒絕；既有 restore destination 拒絕 exit 1。秘密模式掃描覆蓋 47 原檔與原內嵌 tarball 的 36 個 regular files，無模式命中；不是普遍無秘密證明。原 nested tarball 的 44 entries 無 unsafe path/link/special type。

還原命令（destination 必須不存在；從本輪 worktree 執行）：

```sh
python3 docs/evidence/classic-canary-review-20260908/verify_archive.py restore \
  --git-source . --destination /tmp/classic-review-restored-owner
```

全部原始相對路徑映射與固定 commit 連結見 committed `docs/evidence/classic-canary-review-20260908/README.md`。獨立 `classic-canary-linux-20260909` 證據及舊 refs/commits 未移動或改寫。

## 本機驗證與限制

工具鏈 Node v22.23.2 / npm 10.9.8，credential-free HOME，鎖檔 npm ci exit 0。詳見 `local-validation-matrix.json` 及各命令的原始 stdout/stderr、command/cwd/time/exit metadata。

| Check | Final exit/result |
| --- | --- |
| 修改的兩個測試檔與兩個新反例 | 0, 34/34 |
| `npm run verify:action-inventory` | 0, 2 manifests / 7 occurrences |
| typecheck / build | 各 0 |
| audit diagnostics | 0, 32/32 |
| `npm run check` | 0, 696/696, 0 failed/skipped |
| 原 workflow 完整 Security checker pipeline | 0, 227/227, 0 failed/skipped |
| Checkpoint E / E corrective / F tests | 各 0, 30/30, 15/15, 40/40 |
| E/F evidence generate + verify | 四項各 0，兩個 projectSuite 696/696 |
| archive verify / restore / Git bytes comparison | 0, 47 files / original manifest 45 entries |
| 工作樹、stacked base、main、Checkpoint F base、原 PR #14 base whitespace diffs | 五項各 0 |

早期開發測試原始失敗亦保留：新增測試曾誤將 inventory consistency helper 當作 policy 判定，刪除此新增的錯誤 assertion，原 scanner 的拒絕 assertion 保留。最終兩個反例均通過。macOS 清空環境後預設 `/tmp` 指向 `/private/tmp`，造成 CLI main-path 比對與 fixture output 不成立；指定實體 `TMPDIR=/private/tmp` 後 diagnostics/check/security 全通過，沒有為此改 verifier 或測試政策。初始 check/security/diagnostics 各 24 failures 都保留在原始矩陣。

本機 E/F evidence 的 source/tested HEAD 正確為新 SHA；其 local resolver 記錄的 base 是原工具算出的 `a168c487e210306aab17cf428dec67d8168b68fe`，不是 stacked PR base。沒有手改生成 JSON。GitHub PR evidence 的真實 base/source/checkout 身分另行核對。

## 原 scoped Linux 重驗的精確邊界

Run `34257856526`, attempt 3, job `102349201604`: success。Tool HEAD `40223bb5e106668e2d5a2c8971579b41e7a9dbfa`，固定 target `fd9c1e0bbe920bce6e06dd39d364f0e2e82456cf`，target tree `7f14f66eac518c4427076f18fbcfdc7d935c79d8`。25 driver regressions、122 canary tests，driver exit 0。原始六個 workflow outcomes（包含 upload）均 success。Artifact `10089752885` digest `3b6fab4cd627471b2033ea8d23fc988fee919944b20d56103b68b5eeadb201f8` 已驗，內外 465 筆 checksum 全吻合。

既有 scoped workflow 的 base/head filter 不觸發本輪 stacked PR；既有 driver 相對固定 target 的允許範圍也不含本輪兩個測試檔。沒有擴大政策、改 workflow 或把舊 tool/target 重跑冒充新 HEAD 的 scoped 成功。新 HEAD 的 Linux 主 CI 是另一份驗證。Scoped audit 零漏洞不能解除 root blocker。

## 依賴 owner 決策與禁止跨階段

沿用 [PR #13 固定 SHA 的前提／Route A–B 紀錄](https://github.com/danny0971haha/classic-grid/blob/e420b317dc7f7166f70d24701763c0ab15364c68/docs/evidence/dependency-prereq-20260908/classic-handoff.md)。這是既有來源紀錄，沒有重新進行 SDK 調查。

Route A 仍需供應者提供可驗證 npm artifact ↔ immutable source mapping、parent engine proto/buf、Nix/openapi build inputs 與實際 pinned toolchain；歷史 parser replay 還需原 harness/fixtures。Owner 如考慮 Route B，須另行明確決定是否允許 canary-scoped qualification 及要獨立審查的 exact identity，同時保留 root High 可見且 blocking。本輪未選擇 Route B，也未新增 waiver、override、baseline 或依賴變動。

Root lock SHA256 保持 `f278d8b7f0d559839e35ee64e94db9e39c7d6037f5692d0cafa02ba6c6b254ed`。所有 runtime、vendor、packages、workflow、existing security policy/tooling 與独立 Linux evidence object IDs 前後一致，見 `unchanged-scope-objects.json`。

## 新 SHA 的 GitHub CI 對帳

[CI run 34315427266, attempt 1](https://github.com/danny0971haha/classic-grid/actions/runs/34315427266/attempts/1)，job `102350517851`，結果 **failure**。Source HEAD 為新 `ff3d896…`；GitHub tested merge checkout `91cf2a5bd4382185236dc45b20cb5da60d117052` 的 tree 已獨立 fetch 核對，與新 HEAD 同為 `fb693000a7ea157b0995ee9b58592c53ce072419`。E/F artifacts 的 base 都是 `40223bb…`，工具鏈 Node v22.23.2/npm 10.9.8。

32 個 required 原始 outcomes：30 success、2 failure。原本 attempt 2 的 11 個 required failures 中，本輪消除 9 個非依賴 failures。E/F 上傳已成功，四個 artifacts ZIP 的 SHA256 全部符合 GitHub digest。沒有因 conclusion=success 宣稱 root audit 通過。

| ID | Step | Original outcome | Shell exit |
| --- | --- | --- | --- |
| required_01 | Run actions/checkout@11d5960a326750d5838078e36cf38b85af677262 | success | N/A Action |
| required_02 | Fetch pull-request head for identity | success | 0 |
| required_03 | Run actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 | success | N/A Action |
| required_04 | Pin npm | success | 0 |
| required_05 | Record toolchain and identity | success | 0 |
| required_06 | Run npm ci --no-audit | success | 0 |
| required_07 | Run npm run typecheck | success | 0 |
| required_08 | Audit diagnostic regression tests | success | 0 |
| required_09 | Run npm run test:checkpoint-e | success | 0 |
| required_10 | Run npm run test:checkpoint-e-corrective | success | 0 |
| required_11 | Run npm run test:checkpoint-f | success | 0 |
| required_12 | Run npm run check | success | 0 |
| required_13 | Run npm run build | success | 0 |
| required_14 | Generate Checkpoint E evidence | success | 0 |
| required_15 | Verify Checkpoint E evidence | success | 0 |
| required_16 | Generate Checkpoint F evidence | success | 0 |
| required_17 | Verify Checkpoint F evidence | success | 0 |
| required_18 | Security checker tests | success | 0 |
| required_19 | Dependency audit policy | failure | 1 |
| required_20 | Replay captured live audit offline | failure | 1 |
| required_21 | Verify GitHub Actions inventory | success | 0 |
| required_22 | Canary clean-install regression | success | 0 |
| required_23 | Extended canary dependency boundary | success | 0 |
| required_24 | Record dependency-boundary evidence | success | 0 |
| required_25 | Assert security inventory files | success | 0 |
| required_26 | Production artifact smoke and exact content-manifest verifier | success | 0 |
| required_27 | Whitespace check | success | 0 |
| required_28 | Working tree clean | success | 0 |
| required_29 | Upload Checkpoint E evidence | success | N/A Action |
| required_30 | Upload Checkpoint F evidence | success | N/A Action |
| required_31 | Upload security inventory | success | N/A Action |
| required_32 | Upload dependency-boundary evidence | success | N/A Action |

`required_19` 和 `required_20` 的 **outcome=failure / conclusion=success / shell exit=1**；最終 fail-closed aggregator exit 1。Actions 沒有一般 shell exit code，表中不虛構數字。完整原始 REQUIRED_RESULTS JSON 在 `new-ci-outcomes.json`，逐步 raw logs/時間/exit basis 在 `new-ci-step-logs.json`、`new-ci-validation-matrix.json`。

本次 root audit 於 `2026-09-09T05:40:07.355Z` 真實捕捉，subprocess status=1、signal=null、error=null；16 high、8 moderate、0 critical、24 total。這是本次觀察，沒有固定或要求未來數字一致。`NEW_HIGH` 仍為 toml `GHSA-82x6-q7mm-w9cf`、`GHSA-v5mp-jgw5-2x6j`。另有 axios `GHSA-gcfj-64vw-6mp9` 的 `ADVISORY_SOURCE_RENUMBERED` 資訊，與新增 high 分開處理；亦記錄 `AFFECTED_PACKAGE_ADDED`。既有政策 overallPolicyOk=false。

Root audit JSON SHA256 `c6f9fce7ec0e68c62954ee4f94a1d66a2cfbe3d19166b029fcba62fc091284c9`。Offline replay 的 input 與 captured audit 逐 byte 相同，replay 同樣 overallPolicyOk=false。Root 與 scoped audit 結果分離保存，零漏洞 scoped graph 未清除 root。

上傳後下載核對的 E/F JSON：projectSuite 各 696/696、fail=0、skip=0、processExitCode=0；checkpoint suites 分別 30/30、40/40。兩份原生成 JSON、security/audit-command/audit/replay 原輸出及 dependency boundary evidence 均保存在本報告目錄的 artifact 子目錄，ZIP 和 API digest 清單亦保留。沒有手寫成功 JSON。

## 結束判斷與剩餘事項

A 的過期測試清冊問題已修復；B 的 whitespace 交付格式問題已修復且原始證據可完整還原，未發現未決的原路徑契約衝突。E/F projectSuite → generate → verify → upload 的連鎖失敗已解除。有足夠實際工程與新 SHA CI 證據結束本輪 A/B 修正；**整體 CI 仍 failure，root dependency blocker 未解除**。

剩餘 owner 決策只有上述 PR #13 的依賴路線／前提、若另行選 scoped qualification 時的 exact review identity 與政策授權。新分支未獲得既有 scoped driver 的新 HEAD coverage；原固定組合重驗已分別保存，沒有必要或授權為本次 A/B 修正放寬它的範圍。

最終再次查核：所有本輪開始時存在的遠端 refs 未變（含 PR #12/#13/#14、frozen R1/R2-A、既有證據 refs）；唯一新增為本輪 branch 與 PR #15 refs。原使用者 worktree status 與開始時一致，三個未發布提交保留。本輪 task worktree 乾淨。到此停止，沒有開始其他交易階段。

import hashlib, importlib.util, json, pathlib, subprocess, zipfile, datetime
root=pathlib.Path('/private/tmp/classic-ci-inventory-evidence-20260909')
out=pathlib.Path('/private/tmp/classic-closeout-20260909')
old=pathlib.Path('/private/tmp/classic-ci-inventory-evidence-results-20260909')
sha=lambda b:hashlib.sha256(b).hexdigest()
result={'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
rows=[]
for zpath in sorted((out/'downloads').glob('100*.zip')):
    unpack=out/'unpacked'/zpath.stem
    with zipfile.ZipFile(zpath) as z:
        names=set()
        for member in z.infolist():
            if member.is_dir():continue
            name=member.filename
            p=pathlib.PurePosixPath(name)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
            assert name not in names
            names.add(name)
            assert (unpack/name).read_bytes()==z.read(member),name
        assert names=={p.relative_to(unpack).as_posix() for p in unpack.rglob('*') if p.is_file()}
        rows.append({'artifactId':zpath.stem,'zipSha256':sha(zpath.read_bytes()),'exactDownloadedMemberCount':len(names)})
result['downloadedExtractionCompared']=rows
package=root/'docs/evidence/classic-canary-review-20260908'
spec=importlib.util.spec_from_file_location('historical_archive_verifier',package/'verify_archive.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.verify_package(package)
manifest=json.loads((package/'archive-manifest.json').read_text())
files=module.verify_archive(package/'original-evidence.tar.gz',manifest,root)
restored=old/'independently-restored'
assert {p.relative_to(restored).as_posix() for p in restored.rglob('*') if p.is_file()}==set(files)
for name,data in files.items():
    p=restored/name
    assert p.is_file() and not p.is_symlink()
    assert p.read_bytes()==data
    assert p.stat().st_mode & 0o777 == 0o644
result['historicalArchive']={'existingVerifier':'verify_package + verify_archive(git_source)','sourceCommit':manifest['sourceCommit'],'sourceTree':manifest['sourceTree'],'archiveSha256':sha((package/'original-evidence.tar.gz').read_bytes()),'files':len(files),'bytes':sum(map(len,files.values())),'originalManifestEntries':45,'existingRestoredFilesReadback':True,'pathsBytesModesGitSourceCompared':True,'historicalRestoreCommand':json.loads((old/'independent-archive-restore/command.json').read_text()),'historicalRestoreStdout':(old/'independent-archive-restore/stdout').read_text(),'noNewRestoreOrRepack':True}
base='40223bb5e106668e2d5a2c8971579b41e7a9dbfa'
head='ff3d896c427c3d0ca2833879655157029040e044'
git=lambda args:subprocess.check_output(['git','-C',str(root)]+args,text=True).strip()
paths=['.github/workflows/ci.yml','.github/workflows/classic-canary-scoped.yml','scripts/security/action-pin-policy.ts','scripts/security/verify-action-inventory.ts','scripts/security','package.json','package-lock.json','packages/extended-canary','src','vendor','tools']
unchanged=[]
for path in paths:
    a=git(['rev-parse',base+':'+path]);b=git(['rev-parse',head+':'+path]);assert a==b,path
    unchanged.append({'path':path,'baseObject':a,'headObject':b})
result['unchangedObjects']=unchanged
assert git(['status','--porcelain=v1'])==''
result['repositoryCleanAfterReadOnlyChecks']=True
print(json.dumps(result,indent=2))

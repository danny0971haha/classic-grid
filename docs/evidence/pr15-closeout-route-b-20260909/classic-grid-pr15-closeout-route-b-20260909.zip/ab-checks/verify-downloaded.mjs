import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import * as E from '/private/tmp/classic-ci-inventory-evidence-20260909/tools/checkpoint-e-evidence.ts';
import * as F from '/private/tmp/classic-ci-inventory-evidence-20260909/tools/checkpoint-f-evidence.ts';
const root = '/private/tmp/classic-ci-inventory-evidence-20260909';
const out = '/private/tmp/classic-closeout-20260909';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const read = path => JSON.parse(fs.readFileSync(path));
const git = args => execFileSync('git', args, {cwd: root, encoding:'utf8'}).trim();
const identity = {
  sourceHeadSha:'ff3d896c427c3d0ca2833879655157029040e044',
  sourceHeadTreeSha:'fb693000a7ea157b0995ee9b58592c53ce072419',
  testedCheckoutSha:'91cf2a5bd4382185236dc45b20cb5da60d117052',
  testedCheckoutTreeSha:'fb693000a7ea157b0995ee9b58592c53ce072419',
  baseSha:'40223bb5e106668e2d5a2c8971579b41e7a9dbfa',
  githubEventName:'pull_request',githubRunId:'34315427266',
  githubRunAttempt:'1',githubJobId:'compiler-and-tests'
};
assert.equal(git(['rev-parse','HEAD']),identity.sourceHeadSha);
assert.equal(git(['status','--porcelain=v1']),'');
for (const prefix of ['sourceHead','testedCheckout']) {
  assert.equal(git(['rev-parse',identity[prefix+'Sha']+'^{tree}']),identity[prefix+'TreeSha']);
}
const ciLog=fs.readFileSync(out+'/remote/ci-job.log','utf8');
for (const value of [identity.sourceHeadSha,identity.testedCheckoutSha,identity.baseSha,identity.sourceHeadTreeSha]) assert.ok(ciLog.includes(value));
const rows=[];
for (const art of read(out+'/remote/ci-artifacts.json').artifacts) {
  const sha256=hash(fs.readFileSync(out+'/downloads/'+art.id+'.zip'));
  assert.equal('sha256:'+sha256,art.digest);
  assert.equal(art.workflow_run.head_sha,identity.sourceHeadSha);
  assert.equal(art.workflow_run.id,34315427266);
  rows.push({artifactId:art.id,name:art.name,sha256,remoteDigestVerified:true});
}
const checks=[];
for (const [module,id,checkpoint] of [[E,10090040584,'e'],[F,10090040797,'f']]) {
  const path=out+'/unpacked/'+id+'/classic-v0.2-checkpoint-'+checkpoint+'-results.json';
  const bytes=fs.readFileSync(path), doc=JSON.parse(bytes);
  assert.deepEqual(doc.identity,identity);
  const verified=module.verifyEvidence(doc,{identity,fileHashes:module.collectFileHashes(root),branch:module.BRANCH,root});
  checks.push({checkpoint,artifactId:id,inputSha256:hash(bytes),existingVerifier:'verifyEvidence',identityCheckedAgainstGitAndRawCILog:true,requiredFileHashesComparedToCleanPR15Tree:true,checkpointTotal:verified.checkpointSuite.total,projectTotal:verified.projectSuite.total});
}
const dep=read(out+'/unpacked/10090041260/classic-v0.2-dependency-boundary-corrective-1.json');
const {evidenceSha256,...body}=dep;
assert.equal(hash(JSON.stringify(body)),evidenceSha256);
assert.equal(dep.resultSha,identity.testedCheckoutSha);
assert.equal(dep.resultTreeSha,identity.testedCheckoutTreeSha);
assert.equal(git(['rev-parse',dep.baseSha+'^{tree}']),dep.baseTreeSha);
assert.equal(dep.rootLockfileSha256,hash(fs.readFileSync(root+'/package-lock.json')));
assert.equal(dep.canaryLockfileSha256,hash(fs.readFileSync(root+'/packages/extended-canary/package-lock.json')));
const ver=read(out+'/unpacked/10090041028/security/extended-canary-verification.json');
const audit=read(out+'/unpacked/10090041028/security/audit.json');
assert.equal(dep.canaryArtifactSha256,ver.artifactSha256);
assert.deepEqual(dep.loadedModuleInventory,ver.loadedModuleInventory);
assert.deepEqual(dep.forbiddenCanaryPackagesPresent,ver.forbiddenLoaded);
assert.equal(dep.rootAuditHigh,audit.metadata.vulnerabilities.high);
assert.equal(dep.rootAuditCritical,audit.metadata.vulnerabilities.critical);
assert.equal(dep.canaryAuditHigh,ver.audit.high);
assert.equal(dep.canaryAuditCritical,ver.audit.critical);
assert.deepEqual(dep.commandExitCodes,{fullTest:0,checkpointE:0,checkpointF:0,security:0});
assert.equal(dep.fullTestTotal,696); assert.equal(dep.fullTestPass,696); assert.equal(dep.fullTestFail,0); assert.equal(dep.fullTestSkip,0);
assert.equal(dep.checkpointETotal,30); assert.equal(dep.checkpointEPass,30);
assert.equal(dep.checkpointFTotal,40); assert.equal(dep.checkpointFPass,40);
assert.equal(dep.securityTestTotal,83); assert.equal(dep.securityTestPass,83);
console.log(JSON.stringify({scope:'downloaded-packet verification only; no suite execution',toolNode:process.version,artifacts:rows,checkpoints:checks,dependencyBoundary:{artifactId:10090041260,evidenceSha256,contentDigestVerified:true,gitIdentityVerified:true,lockfilesVerified:true,crossArtifactFieldsVerified:true,rootAuditHigh:dep.rootAuditHigh,canaryAuditHigh:dep.canaryAuditHigh,fullSuite:696,securitySuite:83}},null,2));
